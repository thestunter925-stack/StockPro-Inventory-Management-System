# StockPro Earn — Full-Stack Starter

A legitimate company-funded rewards marketplace starter. This scaffold includes a Next.js-style web app, Express API, Prisma schema, secure authentication patterns, wallet ledger, and payment webhook placeholders.

## Run
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env`.
3. Install dependencies in `apps/api` and `apps/web`.
4. Run Prisma migrations from `apps/api`.
5. Start the API and web app.

Payment credentials and production payout logic are intentionally not hard-coded. Connect an approved provider and verify webhooks server-side before enabling real money features.
