import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import argon2 from 'argon2';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';

const app=express(), prisma=new PrismaClient();
app.use(helmet());
app.use(cors({origin:process.env.WEB_ORIGIN||'http://localhost:3000',credentials:true}));
app.use(express.json({limit:'1mb'}));

const secret=process.env.JWT_SECRET;
if(!secret) throw new Error('JWT_SECRET is required');

const auth=async(req:any,res:any,next:any)=>{
  try{
    const token=(req.headers.authorization||'').replace('Bearer ','');
    const payload:any=jwt.verify(token,secret);
    req.user=await prisma.user.findUnique({where:{id:payload.sub}});
    if(!req.user) return res.status(401).json({error:'Unauthorized'});
    next();
  }catch{return res.status(401).json({error:'Unauthorized'});}
};

app.get('/health',(_,res)=>res.json({ok:true}));

app.post('/auth/register',async(req,res)=>{
  const schema=z.object({name:z.string().min(2),email:z.string().email(),password:z.string().min(8)});
  const parsed=schema.safeParse(req.body); if(!parsed.success)return res.status(400).json({error:'Invalid registration data'});
  const {name,email,password}=parsed.data;
  if(await prisma.user.findUnique({where:{email}}))return res.status(409).json({error:'Email already registered'});
  const user=await prisma.user.create({data:{name,email,passwordHash:await argon2.hash(password),wallet:{create:{}}},select:{id:true,name:true,email:true,role:true}});
  res.status(201).json({user});
});

app.post('/auth/login',async(req,res)=>{
  const parsed=z.object({email:z.string().email(),password:z.string()}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'Invalid credentials'});
  const user=await prisma.user.findUnique({where:{email:parsed.data.email}});
  if(!user || !(await argon2.verify(user.passwordHash,parsed.data.password)))return res.status(401).json({error:'Invalid credentials'});
  const token=jwt.sign({sub:user.id,role:user.role},secret,{expiresIn:'1h'});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,role:user.role}});
});

app.get('/me',auth,(req:any,res)=>res.json({user:{id:req.user.id,name:req.user.name,email:req.user.email,role:req.user.role}}));

app.get('/wallet',auth,async(req:any,res)=>{
  const wallet=await prisma.wallet.findUnique({where:{userId:req.user.id}});
  res.json(wallet);
});

app.post('/withdrawals',auth,async(req:any,res)=>{
  const parsed=z.object({amount:z.number().positive()}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'Invalid amount'});
  const wallet=await prisma.wallet.findUnique({where:{userId:req.user.id}});
  if(!wallet || Number(wallet.available)<parsed.data.amount)return res.status(400).json({error:'Insufficient available balance'});
  const result=await prisma.$transaction(async(tx)=>{
    await tx.wallet.update({where:{userId:req.user.id},data:{available:{decrement:parsed.data.amount}}});
    return tx.withdrawal.create({data:{userId:req.user.id,amount:parsed.data.amount}});
  });
  res.status(201).json(result);
});

app.post('/payments/webhook',async(req,res)=>{
  // Verify the payment provider's signature here before changing balances.
  // Use an idempotency key/reference and a database transaction.
  res.status(501).json({error:'Provider webhook not configured'});
});

app.listen(Number(process.env.API_PORT||4000),()=>console.log('API listening'));
